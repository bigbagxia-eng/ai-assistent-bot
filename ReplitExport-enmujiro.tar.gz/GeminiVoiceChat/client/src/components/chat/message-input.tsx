import { useState, useRef, useEffect } from "react";
import { useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, Mic } from "lucide-react";
import { useChat } from "@/hooks/use-chat";
import { useLanguage } from "@/hooks/use-language";
import { cn } from "@/lib/utils";

export function MessageInput() {
  const { chatId } = useParams<{ chatId?: string }>();
  const [message, setMessage] = useState("");
  const [isListening, setIsListening] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { sendMessage, isLoading } = useChat(chatId);
  const { t } = useLanguage();

  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = "auto";
      textarea.style.height = Math.min(textarea.scrollHeight, 128) + "px";
    }
  }, [message]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || isLoading) return;

    const messageText = message.trim();
    setMessage("");
    
    try {
      await sendMessage(messageText);
    } catch (error) {
      console.error("Failed to send message:", error);
      // Restore message on error
      setMessage(messageText);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      console.error("Speech recognition not supported");
      return;
    }

    const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setMessage(prev => prev + transcript);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error:", event.error);
      setIsListening(false);
    };

    recognition.start();
  };

  return (
    <div className="border-t border-border bg-background px-4 py-3">
      <form onSubmit={handleSubmit} className="flex items-end gap-3 max-w-4xl mx-auto">
        <div className="flex-1 relative">
          <Textarea
            ref={textareaRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={t("type_message")}
            className="min-h-[44px] max-h-32 resize-none rounded-2xl pr-12 bg-muted/50 border-input"
            disabled={isLoading}
            rows={1}
          />
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className={cn(
              "absolute right-3 bottom-2 h-6 w-6 p-0",
              isListening && "text-red-500"
            )}
            onClick={handleVoiceInput}
            disabled={isLoading}
          >
            <Mic className="h-4 w-4" />
          </Button>
        </div>
        
        <Button
          type="submit"
          disabled={!message.trim() || isLoading}
          className="h-11 w-11 rounded-xl p-0"
        >
          <Send className="h-4 w-4" />
        </Button>
      </form>
      
      <div className="text-xs text-center text-muted-foreground mt-2">
        {t("ai_powered_by")}
      </div>
    </div>
  );
}

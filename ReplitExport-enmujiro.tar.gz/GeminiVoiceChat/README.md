# AI Assistant - Multilingual Chat Application

A modern AI-powered chat application built with React, TypeScript, and powered by Google's Gemini AI with optional text-to-speech capabilities via ElevenLabs API.

## Features

- 🤖 **AI Chat**: Powered by Google Gemini API
- 🎙️ **Text-to-Speech**: Optional voice synthesis via ElevenLabs
- 🌍 **Multi-language**: Support for English, Russian, Ukrainian, and Chinese
- 📱 **Mobile Ready**: Android APK generation via GitHub Actions
- 🎨 **Modern UI**: Beautiful gradient design with glass effects
- ⚡ **Real-time**: Fast and responsive chat experience
- 🔐 **Secure**: API keys stored locally, never sent to servers

## Quick Start

1. **Configure API Keys**
   - Get your [Gemini API key](https://makersuite.google.com/app/apikey)
   - Get your [ElevenLabs API key](https://elevenlabs.io/app/speech-synthesis) (optional)

2. **Open Settings**
   - Click the Settings button in the app
   - Add your API keys
   - Choose your language preference
   - Configure voice settings (if using ElevenLabs)

3. **Start Chatting**
   - Create a new chat
   - Send a message to test the AI response
   - Optionally enable voice responses for audio playback

## Language Support

The application supports the following languages:
- 🇺🇸 English
- 🇷🇺 Russian (Русский)
- 🇺🇦 Ukrainian (Українська)
- 🇨🇳 Chinese (中文)

Switch languages anytime via Settings → Language.

## Android APK Deployment

This project is configured for automatic Android APK generation using GitHub Actions.

### Setup for APK Generation

1. **Fork/Copy the Repository** to your GitHub account

2. **Push to GitHub**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/yourusername/ai-assistant.git
   git push -u origin main
   ```

3. **Automatic APK Building**:
   - GitHub Actions will automatically build APK on every push to main
   - APK will be available in the Releases section
   - Debug APK will also be uploaded as an artifact

### Manual APK Build

If you want to build locally (requires Android SDK):

```bash
# Install Cordova globally
npm install -g cordova

# Build the web application
npm run build

# Initialize Cordova project (first time only)
cordova platform add android

# Build APK
cordova build android
```

The APK will be generated in `platforms/android/app/build/outputs/apk/debug/app-debug.apk`

## Development

### Prerequisites
- Node.js 20+
- npm or yarn

### Running Locally

1. Clone the repository
2. Install dependencies: `npm install`
3. Start development server: `npm run dev`
4. Open http://localhost:5000

### Project Structure

```
├── client/src/          # Frontend React application
│   ├── components/      # Reusable UI components
│   ├── pages/          # Page components
│   ├── hooks/          # Custom React hooks
│   └── lib/            # Utilities and i18n
├── server/             # Backend Express server
│   ├── services/       # AI and voice synthesis services
│   └── routes.ts       # API endpoints
├── shared/            # Shared TypeScript schemas
├── .github/workflows/ # GitHub Actions for APK building
└── config.xml         # Cordova configuration
```

## Configuration

### API Keys
- **Gemini API Key**: Required for AI responses
- **ElevenLabs API Key**: Optional for text-to-speech

### Voice Settings
- **Voice Model**: Rachel (default), Josh, Arnold, Adam
- **Speech Speed**: Adjustable from 0.5x to 2.0x
- **Auto-play**: Toggle automatic voice playback

### Response Settings
- **Length**: Short (500 tokens), Medium (1000), Long (2000)

## Privacy & Security

- All API keys are stored locally in your browser
- Keys are never sent to our servers
- Communication is direct between your device and API providers
- No user data is collected or stored on external servers

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

If you encounter any issues or have questions:
1. Check the [Issues](../../issues) section
2. Create a new issue with detailed information
3. Include your browser/device information and steps to reproduce

## Acknowledgments

- [Google Gemini AI](https://ai.google.dev/) - For powering the conversational AI
- [ElevenLabs](https://elevenlabs.io/) - For voice synthesis capabilities
- [Replit](https://replit.com/) - For development environment
- [GitHub Actions](https://github.com/features/actions) - For automated APK building
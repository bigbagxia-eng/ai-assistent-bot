import { useState, useEffect } from "react";
import { type Language, useTranslation } from "@/lib/i18n";
import { useSettings } from "@/hooks/use-settings";

export function useLanguage() {
  const { settings, updateSettings } = useSettings();
  const [currentLanguage, setCurrentLanguage] = useState<Language>('en');
  const { t } = useTranslation(currentLanguage);

  useEffect(() => {
    if (settings?.language) {
      setCurrentLanguage(settings.language as Language);
    }
  }, [settings]);

  const changeLanguage = async (language: Language) => {
    setCurrentLanguage(language);
    if (settings) {
      await updateSettings({ ...settings, language });
    }
  };

  return {
    currentLanguage,
    changeLanguage,
    t,
  };
}
interface ElevenLabsVoice {
  voice_id: string;
  name: string;
}

interface ElevenLabsResponse {
  audioUrl?: string;
  error?: string;
}

export async function synthesizeSpeech(
  text: string,
  voiceModel: string = "rachel",
  speed: string = "1.0",
  apiKey?: string
): Promise<ElevenLabsResponse> {
  try {
    const effectiveApiKey = apiKey || process.env.ELEVENLABS_API_KEY || process.env.VITE_ELEVENLABS_API_KEY;
    
    if (!effectiveApiKey) {
      return {
        error: "ElevenLabs API key not configured. Please add your API key in settings."
      };
    }

    // Voice ID mapping (these are example IDs - replace with actual ElevenLabs voice IDs)
    const voiceIds: Record<string, string> = {
      rachel: "21m00Tcm4TlvDq8ikWAM",
      josh: "TxGEqnHWrfWFTfGW9XjX", 
      arnold: "VR6AewLTigWG4xSOukaG",
      adam: "pNInz6obpgDQGcFmaJgB"
    };

    const voiceId = voiceIds[voiceModel] || voiceIds.rachel;

    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: "POST",
      headers: {
        "Accept": "audio/mpeg",
        "Content-Type": "application/json",
        "xi-api-key": effectiveApiKey,
      },
      body: JSON.stringify({
        text: text,
        model_id: "eleven_monolingual_v1",
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.5,
          speed: parseFloat(speed)
        }
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("ElevenLabs API error:", errorText);
      
      let errorMessage = "Failed to synthesize speech. ";
      
      if (response.status === 401) {
        errorMessage += "Invalid API key. Please check your ElevenLabs API key in settings.";
      } else if (response.status === 429) {
        errorMessage += "API rate limit exceeded. Please try again later.";
      } else {
        errorMessage += "Please try again later.";
      }

      return { error: errorMessage };
    }

    const audioBuffer = await response.arrayBuffer();
    const audioBlob = new Blob([audioBuffer], { type: "audio/mpeg" });
    const audioUrl = URL.createObjectURL(audioBlob);

    return { audioUrl };
  } catch (error: any) {
    console.error("ElevenLabs synthesis error:", error);
    return {
      error: "Failed to synthesize speech. Please check your internet connection and try again."
    };
  }
}

export async function getAvailableVoices(apiKey?: string): Promise<ElevenLabsVoice[]> {
  try {
    const effectiveApiKey = apiKey || process.env.ELEVENLABS_API_KEY || process.env.VITE_ELEVENLABS_API_KEY;
    
    if (!effectiveApiKey) {
      // Return default voices if no API key
      return [
        { voice_id: "rachel", name: "Rachel" },
        { voice_id: "josh", name: "Josh" },
        { voice_id: "arnold", name: "Arnold" },
        { voice_id: "adam", name: "Adam" }
      ];
    }

    const response = await fetch("https://api.elevenlabs.io/v1/voices", {
      headers: {
        "xi-api-key": effectiveApiKey,
      },
    });

    if (!response.ok) {
      throw new Error("Failed to fetch voices");
    }

    const data = await response.json();
    return data.voices || [];
  } catch (error) {
    console.error("Failed to fetch ElevenLabs voices:", error);
    // Return default voices on error
    return [
      { voice_id: "rachel", name: "Rachel" },
      { voice_id: "josh", name: "Josh" },
      { voice_id: "arnold", name: "Arnold" },
      { voice_id: "adam", name: "Adam" }
    ];
  }
}

import { useEffect, useRef } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Bot, User, Play, Copy, ThumbsUp, ThumbsDown, Settings } from "lucide-react";
import { useChat } from "@/hooks/use-chat";
import { synthesizeAndPlay } from "@/lib/speech";
import { useSettings } from "@/hooks/use-settings";
import { useLanguage } from "@/hooks/use-language";
import { cn } from "@/lib/utils";
import type { Message } from "@shared/schema";

export function MessageList() {
  const { chatId } = useParams<{ chatId?: string }>();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { isLoading: isSending } = useChat(chatId);
  const { settings } = useSettings();
  const { t } = useLanguage();

  const { data: messages = [], isLoading } = useQuery<Message[]>({
    queryKey: ["/api/chats", chatId, "messages"],
    enabled: !!chatId,
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handlePlayVoice = async (text: string) => {
    if (!settings?.elevenLabsApiKey) {
      console.error("ElevenLabs API key not configured");
      return;
    }

    try {
      await synthesizeAndPlay(text, {
        voiceModel: settings.voiceModel || "rachel",
        speed: settings.speechSpeed || "1.0",
        apiKey: settings.elevenLabsApiKey,
      });
    } catch (error) {
      console.error("Failed to play voice:", error);
    }
  };

  const handleCopyMessage = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  if (!chatId) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-emerald-50 dark:from-gray-900 dark:via-gray-800 dark:to-emerald-900 p-4">
        <div className="max-w-2xl w-full">
          <Card className="chat-card glass border-0 bg-white/80 dark:bg-gray-800/80 text-center p-12">
            <div className="w-24 h-24 bg-gradient-to-br from-primary via-blue-500 to-emerald-500 animate-gradient rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
              <Bot className="h-12 w-12 text-white" />
            </div>
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-gray-900 via-blue-900 to-emerald-900 dark:from-white dark:via-blue-200 dark:to-emerald-200 bg-clip-text text-transparent">
              {t("welcome_title")}
            </h1>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              {t("welcome_description")}
            </p>
            <div className="space-y-4">
              <Button 
                onClick={() => window.dispatchEvent(new CustomEvent('openSettings'))}
                size="lg"
                className="w-full text-lg py-6 bg-gradient-to-r from-primary to-emerald-500 hover:from-primary/90 hover:to-emerald-500/90 text-white border-0 shadow-lg"
              >
                <Settings className="h-5 w-5 mr-3" />
                {t("quick_setup")}
              </Button>
              <div className="flex items-center justify-center gap-8 mt-8 pt-6 border-t border-border">
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Bot className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <span className="text-sm text-muted-foreground">Gemini AI</span>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Play className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <span className="text-sm text-muted-foreground">ElevenLabs</span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex-1 p-4 space-y-4 bg-muted/30 overflow-y-auto">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="flex gap-3">
            <Skeleton className="w-8 h-8 rounded-full" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto bg-gradient-to-b from-background via-muted/20 to-background p-4 space-y-4">
      {messages.map((message) => (
        <div
          key={message.id}
          className={cn(
            "flex gap-3 max-w-4xl",
            message.role === "user" ? "justify-end ml-auto" : "justify-start"
          )}
        >
          {message.role === "assistant" && (
            <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
              <Bot className="h-4 w-4 text-white" />
            </div>
          )}

          <div
            className={cn(
              "max-w-[80%] md:max-w-[70%] rounded-2xl px-4 py-3 shadow-sm",
              message.role === "user"
                ? "bg-gradient-to-r from-primary to-blue-600 text-primary-foreground rounded-br-md border-0"
                : "bg-white dark:bg-gray-800 border border-border rounded-bl-md chat-card"
            )}
          >
            <div className="message-content prose prose-sm max-w-none dark:prose-invert">
              <p className="whitespace-pre-wrap leading-relaxed mb-0">
                {message.content}
              </p>
            </div>

            <div className={cn(
              "flex items-center gap-2 mt-3 text-xs",
              message.role === "user" 
                ? "justify-end text-primary-foreground/70" 
                : "justify-between text-muted-foreground"
            )}>
              {message.role === "assistant" && (
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 px-1.5 text-xs"
                    onClick={() => handlePlayVoice(message.content)}
                  >
                    <Play className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 px-1.5 text-xs"
                    onClick={() => handleCopyMessage(message.content)}
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-6 px-1.5 text-xs">
                    <ThumbsUp className="h-3 w-3" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-6 px-1.5 text-xs">
                    <ThumbsDown className="h-3 w-3" />
                  </Button>
                </div>
              )}
              <span>{new Date(message.timestamp).toLocaleTimeString()}</span>
            </div>
          </div>

          {message.role === "user" && (
            <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0 mt-1">
              <User className="h-4 w-4" />
            </div>
          )}
        </div>
      ))}

      {/* Typing indicator */}
      {isSending && (
        <div className="flex gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-primary rounded-full flex items-center justify-center flex-shrink-0">
            <Bot className="h-4 w-4 text-white" />
          </div>
          <div className="bg-card border px-4 py-3 rounded-2xl rounded-bl-md shadow-sm">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse"></div>
              <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse [animation-delay:0.2s]"></div>
              <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse [animation-delay:0.4s]"></div>
            </div>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  );
}

import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY || "" 
});

export interface GeminiResponse {
  content: string;
  error?: string;
}

export async function generateResponse(
  messages: Array<{ role: "user" | "assistant"; content: string }>,
  maxTokens: "short" | "medium" | "long" = "medium",
  apiKey?: string
): Promise<GeminiResponse> {
  try {
    const effectiveApiKey = apiKey || process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY;
    
    if (!effectiveApiKey) {
      return {
        content: "",
        error: "Gemini API key not configured. Please add your API key in settings."
      };
    }

    const genAI = new GoogleGenAI({ apiKey: effectiveApiKey });

    // Convert messages to Gemini format
    const conversation = messages.map(msg => {
      if (msg.role === "user") {
        return `User: ${msg.content}`;
      } else {
        return `Assistant: ${msg.content}`;
      }
    }).join("\n\n");

    const lastUserMessage = messages.filter(m => m.role === "user").pop()?.content || "";

    let systemPrompt = "You are a helpful AI assistant. Provide accurate, helpful, and engaging responses.";
    
    // Adjust response length based on setting
    switch (maxTokens) {
      case "short":
        systemPrompt += " Keep responses concise and under 500 tokens.";
        break;
      case "long":
        systemPrompt += " Provide detailed, comprehensive responses when appropriate.";
        break;
      default:
        systemPrompt += " Provide balanced responses of moderate length.";
    }

    const response = await genAI.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
      },
      contents: lastUserMessage,
    });

    const content = response.text || "I apologize, but I couldn't generate a response. Please try again.";

    return {
      content: content.trim(),
    };
  } catch (error: any) {
    console.error("Gemini API error:", error);
    
    let errorMessage = "Failed to generate response. ";
    
    if (error.message?.includes("API_KEY_INVALID")) {
      errorMessage += "Invalid API key. Please check your Gemini API key in settings.";
    } else if (error.message?.includes("QUOTA_EXCEEDED")) {
      errorMessage += "API quota exceeded. Please check your Gemini account.";
    } else {
      errorMessage += "Please try again or check your internet connection.";
    }

    return {
      content: "",
      error: errorMessage
    };
  }
}

export function generateChatTitle(firstMessage: string): string {
  // Generate a short title from the first user message
  const title = firstMessage.slice(0, 50).trim();
  return title.length < firstMessage.length ? title + "..." : title;
}

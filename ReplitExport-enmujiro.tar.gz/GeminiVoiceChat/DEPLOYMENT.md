# 🚀 Развертывание на GitHub для автоматической сборки APK

## Пошаговая инструкция

### 1. Подготовка проекта

Ваш проект уже готов к развертыванию! Все файлы настроены:
- ✅ GitHub Actions workflow (`.github/workflows/build-android.yml`)
- ✅ Cordova конфигурация (`config.xml`)
- ✅ Многоязычное приложение с современным дизайном
- ✅ Полная интеграция Gemini AI и ElevenLabs

### 2. Создание репозитория на GitHub

1. Зайдите на [GitHub.com](https://github.com)
2. Нажмите "New repository"
3. Название: `ai-assistant-chatbot`
4. Описание: `AI-powered multilingual chat application with Android APK support`
5. Выберите "Public" (для бесплатного GitHub Actions)
6. НЕ добавляйте README, .gitignore или license (они уже есть в проекте)
7. Нажмите "Create repository"

### 3. Выгрузка кода на GitHub

Выполните эти команды в терминале Replit:

```bash
# Инициализация git репозитория
git init

# Добавление всех файлов
git add .

# Первый коммит
git commit -m "Initial commit: AI Assistant with multilingual support and Android APK generation"

# Добавление удаленного репозитория (замените YOUR_USERNAME на ваш GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/ai-assistant-chatbot.git

# Создание основной ветки
git branch -M main

# Отправка кода на GitHub
git push -u origin main
```

### 4. Автоматическая сборка APK

После загрузки кода:

1. **GitHub Actions запустится автоматически**
   - Перейдите в раздел "Actions" вашего репозитория
   - Увидите процесс "Build Android APK"
   - Сборка займет 5-10 минут

2. **Получение APK файла**
   - После успешной сборки перейдите в "Releases"
   - Скачайте APK файл из последнего релиза
   - Также APK доступен в "Actions" → "Build APK" → "Artifacts"

### 5. Установка APK на Android

1. Скачайте APK файл на Android устройство
2. Откройте "Настройки" → "Безопасность"
3. Включите "Неизвестные источники" или "Установка из неизвестных источников"
4. Откройте скачанный APK файл
5. Нажмите "Установить"

### 6. Настройка приложения

После установки:

1. Откройте приложение "AI Assistant"
2. Нажмите "Quick Setup" на главной странице
3. Добавьте ваш Gemini API ключ
4. Добавьте ElevenLabs API ключ (опционально)
5. Выберите язык интерфейса
6. Настройте голосовые параметры
7. Начинайте общаться с AI!

## 🔧 Настройка для продакшена

### Подпись APK (для публикации в Play Store)

1. Создайте keystore файл:
```bash
keytool -genkey -v -keystore ai-assistant-release.keystore -alias ai-assistant -keyalg RSA -keysize 2048 -validity 10000
```

2. Добавьте секреты в GitHub:
   - `KEYSTORE_FILE`: Base64 encoded keystore файл
   - `KEYSTORE_PASSWORD`: Пароль keystore
   - `KEY_ALIAS`: Алиас ключа
   - `KEY_PASSWORD`: Пароль ключа

### Автоматические релизы

GitHub Actions настроена на:
- ✅ Автосборку при каждом push в main
- ✅ Создание релиза с APK файлом
- ✅ Версионирование по номеру сборки
- ✅ Автогенерацию release notes

## 📱 Возможности приложения

Ваше приложение поддерживает:

### 🌍 Языки
- 🇺🇸 English
- 🇷🇺 Русский  
- 🇺🇦 Українська
- 🇨🇳 中文

### 🎯 Функции
- Чат с Gemini AI
- Синтез речи через ElevenLabs
- Настройка голосовых моделей
- Сохранение истории чатов
- Темная/светлая тема
- Настройка длины ответов

## 🆘 Устранение проблем

### Если сборка GitHub Actions не удалась:
1. Проверьте логи в разделе "Actions"
2. Убедитесь, что репозиторий публичный
3. Проверьте права доступа в Settings → Actions

### Если APK не устанавливается:
1. Включите "Неизвестные источники" в настройках Android
2. Проверьте, что скачали правильный APK файл
3. Убедитесь, что Android версия 7.0+ (API 24+)

## 🎉 Готово!

Теперь у вас есть:
- ✅ Полнофункциональный AI чат-бот
- ✅ Многоязычная поддержка
- ✅ Android APK приложение
- ✅ Автоматическая сборка через GitHub
- ✅ Современный красивый дизайн

Ваш AI Assistant готов к использованию на любых Android устройствах!
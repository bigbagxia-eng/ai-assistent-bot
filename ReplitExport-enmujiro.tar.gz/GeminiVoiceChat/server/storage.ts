import { type User, type InsertUser, type Chat, type InsertChat, type Message, type InsertMessage, type UserSettings, type InsertUserSettings } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createChat(userId: string, chat: InsertChat): Promise<Chat>;
  getUserChats(userId: string): Promise<Chat[]>;
  getChat(id: string): Promise<Chat | undefined>;
  updateChatTitle(id: string, title: string): Promise<void>;
  deleteChat(id: string): Promise<void>;
  
  createMessage(message: InsertMessage): Promise<Message>;
  getChatMessages(chatId: string): Promise<Message[]>;
  
  getUserSettings(userId: string): Promise<UserSettings | undefined>;
  upsertUserSettings(userId: string, settings: InsertUserSettings): Promise<UserSettings>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private chats: Map<string, Chat>;
  private messages: Map<string, Message>;
  private userSettings: Map<string, UserSettings>;

  constructor() {
    this.users = new Map();
    this.chats = new Map();
    this.messages = new Map();
    this.userSettings = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createChat(userId: string, insertChat: InsertChat): Promise<Chat> {
    const id = randomUUID();
    const now = new Date();
    const chat: Chat = {
      ...insertChat,
      id,
      userId,
      createdAt: now,
      updatedAt: now,
    };
    this.chats.set(id, chat);
    return chat;
  }

  async getUserChats(userId: string): Promise<Chat[]> {
    return Array.from(this.chats.values())
      .filter(chat => chat.userId === userId)
      .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  async getChat(id: string): Promise<Chat | undefined> {
    return this.chats.get(id);
  }

  async updateChatTitle(id: string, title: string): Promise<void> {
    const chat = this.chats.get(id);
    if (chat) {
      chat.title = title;
      chat.updatedAt = new Date();
      this.chats.set(id, chat);
    }
  }

  async deleteChat(id: string): Promise<void> {
    this.chats.delete(id);
    // Also delete associated messages
    const messagesToDelete: string[] = [];
    this.messages.forEach((message, messageId) => {
      if (message.chatId === id) {
        messagesToDelete.push(messageId);
      }
    });
    messagesToDelete.forEach(messageId => this.messages.delete(messageId));
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const now = new Date();
    const message: Message = {
      ...insertMessage,
      id,
      timestamp: now,
      metadata: insertMessage.metadata ? {
        voiceEnabled: typeof insertMessage.metadata.voiceEnabled === 'boolean' ? insertMessage.metadata.voiceEnabled : undefined,
        error: typeof insertMessage.metadata.error === 'string' ? insertMessage.metadata.error : undefined,
      } : null,
    };
    this.messages.set(id, message);

    // Update chat timestamp
    const chat = this.chats.get(insertMessage.chatId);
    if (chat) {
      chat.updatedAt = now;
      this.chats.set(insertMessage.chatId, chat);
    }

    return message;
  }

  async getChatMessages(chatId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.chatId === chatId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async getUserSettings(userId: string): Promise<UserSettings | undefined> {
    return Array.from(this.userSettings.values()).find(
      settings => settings.userId === userId
    );
  }

  async upsertUserSettings(userId: string, insertSettings: InsertUserSettings): Promise<UserSettings> {
    const existing = await this.getUserSettings(userId);
    
    if (existing) {
      const updated: UserSettings = { ...existing, ...insertSettings };
      this.userSettings.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const newSettings: UserSettings = {
        id,
        userId,
        geminiApiKey: insertSettings.geminiApiKey || null,
        elevenLabsApiKey: insertSettings.elevenLabsApiKey || null,
        voiceEnabled: insertSettings.voiceEnabled ?? true,
        autoPlayVoice: insertSettings.autoPlayVoice ?? false,
        voiceModel: insertSettings.voiceModel ?? "rachel",
        speechSpeed: insertSettings.speechSpeed ?? "1.0",
        theme: insertSettings.theme ?? "system",
        maxResponseLength: insertSettings.maxResponseLength ?? "medium",
        language: insertSettings.language ?? "en",
      };
      this.userSettings.set(id, newSettings);
      return newSettings;
    }
  }
}

export const storage = new MemStorage();

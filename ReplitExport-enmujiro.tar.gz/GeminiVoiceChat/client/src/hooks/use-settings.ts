import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { UserSettings, InsertUserSettings } from "@shared/schema";

export function useSettings() {
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery<UserSettings>({
    queryKey: ["/api/settings"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/settings");
      return response.json();
    },
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (newSettings: InsertUserSettings) => {
      const response = await apiRequest("POST", "/api/settings", newSettings);
      return response.json() as Promise<UserSettings>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
  });

  const updateSettings = async (newSettings: InsertUserSettings) => {
    return updateSettingsMutation.mutateAsync(newSettings);
  };

  return {
    settings,
    updateSettings,
    isLoading: isLoading || updateSettingsMutation.isPending,
  };
}

import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateResponse, generateChatTitle } from "./services/gemini";
import { synthesizeSpeech, getAvailableVoices } from "./services/elevenlabs";
import { insertChatSchema, insertMessageSchema, insertUserSettingsSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Create a new chat
  app.post("/api/chats", async (req, res) => {
    try {
      const { title } = insertChatSchema.parse(req.body);
      const userId = req.body.userId || "default-user"; // For demo, using default user
      
      const chat = await storage.createChat(userId, { title });
      res.json(chat);
    } catch (error) {
      res.status(400).json({ error: "Invalid chat data" });
    }
  });

  // Get user's chats
  app.get("/api/chats", async (req, res) => {
    try {
      const userId = req.query.userId as string || "default-user";
      const chats = await storage.getUserChats(userId);
      res.json(chats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch chats" });
    }
  });

  // Get chat messages
  app.get("/api/chats/:chatId/messages", async (req, res) => {
    try {
      const { chatId } = req.params;
      const messages = await storage.getChatMessages(chatId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  // Send a message and get AI response
  app.post("/api/chats/:chatId/messages", async (req, res) => {
    try {
      const { chatId } = req.params;
      const { content, apiKey } = req.body;

      if (!content?.trim()) {
        return res.status(400).json({ error: "Message content is required" });
      }

      // Save user message
      const userMessage = await storage.createMessage({
        chatId,
        role: "user",
        content: content.trim(),
      });

      // Get chat history for context
      const messages = await storage.getChatMessages(chatId);
      const conversationHistory = messages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      // Get user settings for response configuration
      const settings = await storage.getUserSettings("default-user");
      const maxResponseLength = settings?.maxResponseLength || "medium";

      // Generate AI response
      const aiResponse = await generateResponse(conversationHistory, maxResponseLength, apiKey);
      
      if (aiResponse.error) {
        return res.status(500).json({ error: aiResponse.error });
      }

      // Save AI response
      const assistantMessage = await storage.createMessage({
        chatId,
        role: "assistant",
        content: aiResponse.content,
        metadata: { voiceEnabled: settings?.voiceEnabled || false }
      });

      // Update chat title if this is the first exchange
      const allMessages = await storage.getChatMessages(chatId);
      if (allMessages.length === 2) { // First user message + first AI response
        const title = generateChatTitle(content);
        await storage.updateChatTitle(chatId, title);
      }

      res.json({
        userMessage,
        assistantMessage,
        aiResponse: aiResponse.content
      });
    } catch (error) {
      console.error("Message creation error:", error);
      res.status(500).json({ error: "Failed to process message" });
    }
  });

  // Synthesize speech
  app.post("/api/speech/synthesize", async (req, res) => {
    try {
      const { text, voiceModel, speed, apiKey } = req.body;

      if (!text?.trim()) {
        return res.status(400).json({ error: "Text is required for speech synthesis" });
      }

      const result = await synthesizeSpeech(text, voiceModel, speed, apiKey);
      
      if (result.error) {
        return res.status(500).json({ error: result.error });
      }

      res.json({ audioUrl: result.audioUrl });
    } catch (error) {
      console.error("Speech synthesis error:", error);
      res.status(500).json({ error: "Failed to synthesize speech" });
    }
  });

  // Get available voices
  app.get("/api/speech/voices", async (req, res) => {
    try {
      const apiKey = req.query.apiKey as string;
      const voices = await getAvailableVoices(apiKey);
      res.json(voices);
    } catch (error) {
      console.error("Failed to fetch voices:", error);
      res.status(500).json({ error: "Failed to fetch available voices" });
    }
  });

  // Get user settings
  app.get("/api/settings", async (req, res) => {
    try {
      const userId = req.query.userId as string || "default-user";
      const settings = await storage.getUserSettings(userId);
      res.json(settings || {});
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  // Update user settings
  app.post("/api/settings", async (req, res) => {
    try {
      const userId = req.body.userId || "default-user";
      const settingsData = insertUserSettingsSchema.parse(req.body);
      
      const settings = await storage.upsertUserSettings(userId, settingsData);
      res.json(settings);
    } catch (error) {
      console.error("Settings update error:", error);
      res.status(400).json({ error: "Invalid settings data" });
    }
  });

  // Delete chat
  app.delete("/api/chats/:chatId", async (req, res) => {
    try {
      const { chatId } = req.params;
      await storage.deleteChat(chatId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete chat" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useSettings } from "@/hooks/use-settings";
import { synthesizeAndPlay } from "@/lib/speech";
import { useToast } from "./use-toast";
import type { Chat, Message } from "@shared/schema";

export function useChat(chatId?: string) {
  const [, navigate] = useLocation();
  const [isVoiceEnabled, setIsVoiceEnabled] = useState(true);
  const queryClient = useQueryClient();
  const { settings } = useSettings();
  const { toast } = useToast();

  const createChatMutation = useMutation({
    mutationFn: async (title: string = "New Chat") => {
      const response = await apiRequest("POST", "/api/chats", { title });
      return response.json() as Promise<Chat>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chats"] });
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: async ({ chatId, content }: { chatId: string; content: string }) => {
      const response = await apiRequest("POST", `/api/chats/${chatId}/messages`, {
        content,
        apiKey: settings?.geminiApiKey,
      });
      return response.json() as Promise<{
        userMessage: Message;
        assistantMessage: Message;
        aiResponse: string;
      }>;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/chats", chatId, "messages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/chats"] });

      // Auto-play voice if enabled
      if (
        isVoiceEnabled && 
        settings?.autoPlayVoice && 
        settings?.elevenLabsApiKey &&
        data.aiResponse
      ) {
        synthesizeAndPlay(data.aiResponse, {
          voiceModel: settings.voiceModel || "rachel",
          speed: settings.speechSpeed || "1.0",
          apiKey: settings.elevenLabsApiKey,
        }).catch(console.error);
      }
    },
    onError: (error: any) => {
      const errorMessage = error.message || "Failed to send message";
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  const createNewChat = async () => {
    const chat = await createChatMutation.mutateAsync("New Chat");
    return chat;
  };

  const sendMessage = async (content: string) => {
    if (!chatId) {
      // Create new chat first
      const newChat = await createNewChat();
      navigate(`/chat/${newChat.id}`);
      
      // Send message to new chat
      return sendMessageMutation.mutateAsync({
        chatId: newChat.id,
        content,
      });
    }

    return sendMessageMutation.mutateAsync({ chatId, content });
  };

  const toggleVoice = () => {
    setIsVoiceEnabled(prev => !prev);
  };

  return {
    createNewChat,
    sendMessage,
    isLoading: sendMessageMutation.isPending || createChatMutation.isPending,
    isVoiceEnabled,
    toggleVoice,
    currentChat: chatId,
  };
}

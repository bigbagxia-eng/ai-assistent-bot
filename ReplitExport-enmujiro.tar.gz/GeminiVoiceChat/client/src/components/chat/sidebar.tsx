import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Plus, X, MessageSquare, Trash2 } from "lucide-react";
import { useChat } from "@/hooks/use-chat";
import { useLanguage } from "@/hooks/use-language";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import type { Chat } from "@shared/schema";

interface SidebarProps {
  onClose?: () => void;
}

export function Sidebar({ onClose }: SidebarProps) {
  const [location, navigate] = useLocation();
  const { createNewChat } = useChat();
  const { t } = useLanguage();

  const { data: chats = [], refetch } = useQuery<Chat[]>({
    queryKey: ["/api/chats"],
  });

  const handleNewChat = async () => {
    try {
      const newChat = await createNewChat();
      navigate(`/chat/${newChat.id}`);
      onClose?.();
    } catch (error) {
      console.error("Failed to create new chat:", error);
    }
  };

  const handleDeleteChat = async (chatId: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    try {
      await apiRequest("DELETE", `/api/chats/${chatId}`);
      refetch();
      
      // If we're currently in this chat, navigate to home
      if (location.includes(chatId)) {
        navigate("/");
      }
    } catch (error) {
      console.error("Failed to delete chat:", error);
    }
  };

  return (
    <div className="h-full bg-card border-r border-border flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <h2 className="text-lg font-semibold text-card-foreground">{t("ai_assistant")}</h2>
        <Button variant="ghost" size="sm" onClick={onClose} className="lg:hidden">
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* New Chat Button */}
      <div className="p-4">
        <Button 
          onClick={handleNewChat}
          className="w-full justify-center gap-2"
        >
          <Plus className="h-4 w-4" />
          {t("new_chat")}
        </Button>
      </div>

      {/* Chat History */}
      <div className="flex-1 overflow-hidden px-4">
        <h3 className="text-sm font-medium text-muted-foreground mb-3">{t("recent_chats")}</h3>
        <ScrollArea className="h-full">
          <div className="space-y-1">
            {chats.map((chat) => (
              <div key={chat.id} className="group relative">
                <Link href={`/chat/${chat.id}`}>
                  <Button
                    variant="ghost"
                    className={cn(
                      "w-full justify-start text-left h-auto p-3 text-sm",
                      location.includes(chat.id) && "bg-accent text-accent-foreground"
                    )}
                    onClick={onClose}
                  >
                    <MessageSquare className="h-4 w-4 mr-2 flex-shrink-0" />
                    <span className="truncate">{chat.title}</span>
                  </Button>
                </Link>
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute right-1 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => handleDeleteChat(chat.id, e)}
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>

      <Separator />

      {/* Footer */}
      <div className="p-4">
        <div className="text-xs text-center text-muted-foreground">
          {t("powered_by")}
        </div>
      </div>
    </div>
  );
}

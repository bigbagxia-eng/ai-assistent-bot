interface Translations {
  [key: string]: {
    [key: string]: string;
  };
}

export const translations: Translations = {
  en: {
    // Header
    "ai_assistant": "AI Assistant",
    "online": "Online",
    
    // Sidebar
    "new_chat": "New Chat",
    "recent_chats": "Recent Chats",
    "powered_by": "Powered by Gemini & ElevenLabs",
    
    // Welcome screen
    "welcome_title": "Welcome to AI Assistant",
    "welcome_description": "Powered by Gemini AI and ElevenLabs voice synthesis. Configure your API keys to get started.",
    "quick_setup": "Quick Setup",
    
    // Message input
    "type_message": "Type your message here...",
    "ai_powered_by": "AI responses powered by Gemini • Voice by ElevenLabs",
    
    // Settings
    "settings": "Settings",
    "api_configuration": "API Configuration",
    "gemini_api_key": "Gemini API Key",
    "elevenlabs_api_key": "ElevenLabs API Key",
    "get_gemini_key": "Get your Gemini API key →",
    "get_elevenlabs_key": "Get your ElevenLabs API key →",
    "api_keys_secure": "API keys are stored locally on your device and never sent to our servers.",
    "voice_settings": "Voice Settings",
    "voice_model": "Voice Model",
    "speech_speed": "Speech Speed",
    "auto_play_responses": "Auto-play responses",
    "general": "General",
    "voice_responses": "Voice responses",
    "max_response_length": "Max response length",
    "short": "Short",
    "medium": "Medium",
    "long": "Long",
    "save_changes": "Save Changes",
    "cancel": "Cancel",
    "language": "Language",
    
    // Toasts
    "settings_saved": "Settings saved",
    "settings_saved_desc": "Your preferences have been updated successfully.",
    "error": "Error",
    "settings_error": "Failed to save settings. Please try again.",
    
    // Voice models
    "rachel_default": "Rachel (Default)",
    "josh": "Josh",
    "arnold": "Arnold",
    "adam": "Adam",
    
    // Tokens
    "short_tokens": "Short (500 tokens)",
    "medium_tokens": "Medium (1000 tokens)",
    "long_tokens": "Long (2000 tokens)",
  },
  
  ru: {
    // Header
    "ai_assistant": "ИИ Ассистент",
    "online": "В сети",
    
    // Sidebar
    "new_chat": "Новый чат",
    "recent_chats": "Недавние чаты",
    "powered_by": "Работает на Gemini и ElevenLabs",
    
    // Welcome screen
    "welcome_title": "Добро пожаловать в ИИ Ассистент",
    "welcome_description": "Работает на ИИ Gemini и голосовом синтезе ElevenLabs. Настройте API ключи для начала работы.",
    "quick_setup": "Быстрая настройка",
    
    // Message input
    "type_message": "Введите ваше сообщение здесь...",
    "ai_powered_by": "ИИ ответы от Gemini • Голос от ElevenLabs",
    
    // Settings
    "settings": "Настройки",
    "api_configuration": "Настройка API",
    "gemini_api_key": "API ключ Gemini",
    "elevenlabs_api_key": "API ключ ElevenLabs",
    "get_gemini_key": "Получить API ключ Gemini →",
    "get_elevenlabs_key": "Получить API ключ ElevenLabs →",
    "api_keys_secure": "API ключи хранятся локально на вашем устройстве и никогда не отправляются на наши серверы.",
    "voice_settings": "Настройки голоса",
    "voice_model": "Модель голоса",
    "speech_speed": "Скорость речи",
    "auto_play_responses": "Автовоспроизведение ответов",
    "general": "Общие",
    "voice_responses": "Голосовые ответы",
    "max_response_length": "Макс. длина ответа",
    "short": "Короткий",
    "medium": "Средний",
    "long": "Длинный",
    "save_changes": "Сохранить изменения",
    "cancel": "Отмена",
    "language": "Язык",
    
    // Toasts
    "settings_saved": "Настройки сохранены",
    "settings_saved_desc": "Ваши предпочтения успешно обновлены.",
    "error": "Ошибка",
    "settings_error": "Не удалось сохранить настройки. Попробуйте еще раз.",
    
    // Voice models
    "rachel_default": "Рэйчел (По умолчанию)",
    "josh": "Джош",
    "arnold": "Арнольд",
    "adam": "Адам",
    
    // Tokens
    "short_tokens": "Короткий (500 токенов)",
    "medium_tokens": "Средний (1000 токенов)",
    "long_tokens": "Длинный (2000 токенов)",
  },
  
  uk: {
    // Header
    "ai_assistant": "ШІ Асистент",
    "online": "В мережі",
    
    // Sidebar
    "new_chat": "Новий чат",
    "recent_chats": "Останні чати",
    "powered_by": "Працює на Gemini та ElevenLabs",
    
    // Welcome screen
    "welcome_title": "Ласкаво просимо до ШІ Асистента",
    "welcome_description": "Працює на ШІ Gemini та голосовому синтезі ElevenLabs. Налаштуйте API ключі для початку роботи.",
    "quick_setup": "Швидке налаштування",
    
    // Message input
    "type_message": "Введіть ваше повідомлення тут...",
    "ai_powered_by": "ШІ відповіді від Gemini • Голос від ElevenLabs",
    
    // Settings
    "settings": "Налаштування",
    "api_configuration": "Налаштування API",
    "gemini_api_key": "API ключ Gemini",
    "elevenlabs_api_key": "API ключ ElevenLabs",
    "get_gemini_key": "Отримати API ключ Gemini →",
    "get_elevenlabs_key": "Отримати API ключ ElevenLabs →",
    "api_keys_secure": "API ключі зберігаються локально на вашому пристрої і ніколи не відправляються на наші сервери.",
    "voice_settings": "Налаштування голосу",
    "voice_model": "Модель голосу",
    "speech_speed": "Швидкість мови",
    "auto_play_responses": "Автовідтворення відповідей",
    "general": "Загальні",
    "voice_responses": "Голосові відповіді",
    "max_response_length": "Макс. довжина відповіді",
    "short": "Короткий",
    "medium": "Середній",
    "long": "Довгий",
    "save_changes": "Зберегти зміни",
    "cancel": "Скасувати",
    "language": "Мова",
    
    // Toasts
    "settings_saved": "Налаштування збережені",
    "settings_saved_desc": "Ваші налаштування успішно оновлені.",
    "error": "Помилка",
    "settings_error": "Не вдалося зберегти налаштування. Спробуйте ще раз.",
    
    // Voice models
    "rachel_default": "Рейчел (За замовчуванням)",
    "josh": "Джош",
    "arnold": "Арнольд",
    "adam": "Адам",
    
    // Tokens
    "short_tokens": "Короткий (500 токенів)",
    "medium_tokens": "Середній (1000 токенів)",
    "long_tokens": "Довгий (2000 токенів)",
  },
  
  zh: {
    // Header
    "ai_assistant": "AI 助手",
    "online": "在线",
    
    // Sidebar
    "new_chat": "新建聊天",
    "recent_chats": "最近聊天",
    "powered_by": "由 Gemini 和 ElevenLabs 提供支持",
    
    // Welcome screen
    "welcome_title": "欢迎使用 AI 助手",
    "welcome_description": "由 Gemini AI 和 ElevenLabs 语音合成提供支持。配置您的 API 密钥以开始使用。",
    "quick_setup": "快速设置",
    
    // Message input
    "type_message": "在此输入您的消息...",
    "ai_powered_by": "AI 回复由 Gemini 提供 • 语音由 ElevenLabs 提供",
    
    // Settings
    "settings": "设置",
    "api_configuration": "API 配置",
    "gemini_api_key": "Gemini API 密钥",
    "elevenlabs_api_key": "ElevenLabs API 密钥",
    "get_gemini_key": "获取您的 Gemini API 密钥 →",
    "get_elevenlabs_key": "获取您的 ElevenLabs API 密钥 →",
    "api_keys_secure": "API 密钥存储在您的设备本地，绝不会发送到我们的服务器。",
    "voice_settings": "语音设置",
    "voice_model": "语音模型",
    "speech_speed": "语音速度",
    "auto_play_responses": "自动播放回复",
    "general": "通用",
    "voice_responses": "语音回复",
    "max_response_length": "最大回复长度",
    "short": "短",
    "medium": "中等",
    "long": "长",
    "save_changes": "保存更改",
    "cancel": "取消",
    "language": "语言",
    
    // Toasts
    "settings_saved": "设置已保存",
    "settings_saved_desc": "您的设置已成功更新。",
    "error": "错误",
    "settings_error": "保存设置失败。请重试。",
    
    // Voice models
    "rachel_default": "瑞秋（默认）",
    "josh": "乔什",
    "arnold": "阿诺德",
    "adam": "亚当",
    
    // Tokens
    "short_tokens": "短（500 个令牌）",
    "medium_tokens": "中等（1000 个令牌）",
    "long_tokens": "长（2000 个令牌）",
  },
};

export type Language = 'en' | 'ru' | 'uk' | 'zh';

export function useTranslation(language: Language = 'en') {
  const t = (key: string): string => {
    return translations[language]?.[key] || translations['en'][key] || key;
  };

  return { t };
}

// Language names for the language selector
export const languageNames: Record<Language, string> = {
  en: 'English',
  ru: 'Русский',
  uk: 'Українська',
  zh: '中文',
};
# Overview

This is a modern AI-powered chat application built with a full-stack architecture featuring real-time conversations with Google's Gemini AI and optional text-to-speech capabilities via ElevenLabs. The application provides a ChatGPT-like interface with persistent chat history, user settings, and voice synthesis features.

## User Preferences

- Preferred communication style: Simple, everyday language
- Multi-language support: Added Russian, Ukrainian, and Chinese translations
- Design preference: Modern, presentable interface with gradient effects and glass styling
- Mobile deployment: Configured for Android APK generation via GitHub Actions

## System Architecture

### Frontend Architecture
The client-side is built using **React 18** with **TypeScript** and follows a component-based architecture:

- **UI Framework**: Built on top of Radix UI primitives with shadcn/ui components for consistent design
- **Styling**: Tailwind CSS with CSS variables for theming support (light/dark/system modes)
- **State Management**: React Query (@tanstack/react-query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized production builds

The frontend follows a modular structure with:
- **Components**: Reusable UI components organized by feature (chat, ui)
- **Hooks**: Custom React hooks for state management (use-chat, use-settings, use-mobile)
- **Pages**: Route-level components for different application views
- **Library utilities**: Shared utilities for API requests, speech synthesis, and common functions

### Backend Architecture
The server-side uses **Node.js** with **Express** and follows a RESTful API design:

- **Runtime**: Node.js with ESM modules
- **Web Framework**: Express.js with middleware for JSON parsing and request logging
- **Database Layer**: Drizzle ORM with PostgreSQL (Neon Database) for type-safe database operations
- **Storage Pattern**: Abstracted storage interface with in-memory fallback for development
- **AI Integration**: Google Generative AI (@google/genai) for conversational responses
- **Voice Synthesis**: ElevenLabs API integration for text-to-speech functionality

The backend implements a service-oriented architecture with:
- **Routes**: RESTful endpoints for chats, messages, and user settings
- **Services**: Business logic abstraction for AI and voice synthesis
- **Storage**: Database abstraction layer supporting multiple storage backends
- **Middleware**: Request logging, error handling, and development tooling

### Database Design
The application uses **PostgreSQL** with the following schema design:

- **Users**: Basic user management with username/password authentication
- **Chats**: Conversation containers with title, timestamps, and user association
- **Messages**: Individual chat messages with role-based typing (user/assistant)
- **User Settings**: Personalized configuration for API keys, voice preferences, and UI settings

The schema supports:
- UUID primary keys for all entities
- Foreign key relationships for data integrity
- JSON metadata fields for extensible message attributes
- Timestamp tracking for audit trails

### Development Environment
The project uses a monorepo structure with shared TypeScript definitions:

- **Shared Schema**: Common type definitions and validation schemas using Zod
- **Path Aliases**: TypeScript path mapping for clean imports (@/, @shared/)
- **Hot Reloading**: Vite HMR for frontend and tsx for backend development
- **Type Safety**: End-to-end TypeScript with strict configuration

## External Dependencies

### AI Services
- **Google Generative AI**: Primary conversational AI provider using Gemini models
  - Configurable response length (short/medium/long)
  - Context-aware conversation handling
  - User-provided API key support

### Voice Synthesis
- **ElevenLabs**: Text-to-speech service for voice message playback
  - Multiple voice model options (Rachel, Josh, Arnold, Adam)
  - Configurable speech speed settings
  - Optional auto-play functionality

### Database Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting
  - Connection pooling via @neondatabase/serverless
  - Environment-based configuration
  - Migration support through Drizzle Kit

### UI Component Libraries
- **Radix UI**: Headless component primitives for accessibility
- **Tailwind CSS**: Utility-first CSS framework with custom design system and gradient animations
- **Lucide React**: Icon library for consistent iconography

### Internationalization
- **Multi-language Support**: English, Russian, Ukrainian, and Chinese
- **Translation System**: Custom i18n implementation with useTranslation hook
- **Language Persistence**: Language selection stored in user settings

### Mobile Deployment
- **Android APK**: Configured for Cordova-based Android application
- **GitHub Actions**: Automated APK building and distribution
- **Cordova Configuration**: config.xml with proper permissions and settings

### Development Tools
- **Replit Integration**: Development environment optimizations
- **Vite Plugins**: Runtime error handling and cartographer integration
- **ESBuild**: Production build optimization for server bundle
- **GitHub Actions**: CI/CD pipeline for Android APK generation
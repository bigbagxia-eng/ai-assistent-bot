import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent } from "@/components/ui/card";
import { Brain, Volume2, Info, Save, Globe } from "lucide-react";
import { useSettings } from "@/hooks/use-settings";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/hooks/use-language";
import { type Language, languageNames } from "@/lib/i18n";

interface SettingsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SettingsModal({ open, onOpenChange }: SettingsModalProps) {
  const { settings, updateSettings, isLoading } = useSettings();
  const { toast } = useToast();
  const { currentLanguage, changeLanguage, t } = useLanguage();
  
  const [formData, setFormData] = useState({
    geminiApiKey: "",
    elevenLabsApiKey: "",
    voiceEnabled: true,
    autoPlayVoice: false,
    voiceModel: "rachel",
    speechSpeed: "1.0",
    theme: "system" as "light" | "dark" | "system",
    maxResponseLength: "medium" as "short" | "medium" | "long",
    language: "en" as Language,
  });

  // Initialize form data when settings load
  useEffect(() => {
    if (settings) {
      setFormData({
        geminiApiKey: settings.geminiApiKey || "",
        elevenLabsApiKey: settings.elevenLabsApiKey || "",
        voiceEnabled: settings.voiceEnabled ?? true,
        autoPlayVoice: settings.autoPlayVoice ?? false,
        voiceModel: settings.voiceModel || "rachel",
        speechSpeed: settings.speechSpeed || "1.0",
        theme: settings.theme || "system",
        maxResponseLength: settings.maxResponseLength || "medium",
        language: (settings.language as Language) || "en",
      });
    }
  }, [settings]);

  // Listen for quick setup event
  useEffect(() => {
    const handleOpenSettings = () => {
      onOpenChange(true);
    };

    window.addEventListener('openSettings', handleOpenSettings);
    return () => window.removeEventListener('openSettings', handleOpenSettings);
  }, [onOpenChange]);

  const handleSave = async () => {
    try {
      await updateSettings(formData);
      await changeLanguage(formData.language);
      toast({
        title: t("settings_saved"),
        description: t("settings_saved_desc"),
      });
      onOpenChange(false);
    } catch (error) {
      toast({
        title: t("error"),
        description: t("settings_error"),
        variant: "destructive",
      });
    }
  };

  const handleSpeedChange = (value: number[]) => {
    setFormData(prev => ({ ...prev, speechSpeed: value[0].toString() }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t("settings")}</DialogTitle>
          <DialogDescription>
            {t("api_keys_secure")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Language Selection */}
          <div>
            <h4 className="text-lg font-medium mb-4 flex items-center gap-2">
              <Globe className="h-5 w-5 text-primary" />
              {t("language")}
            </h4>
            <Select
              value={formData.language}
              onValueChange={(value: Language) => setFormData(prev => ({ ...prev, language: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(languageNames).map(([code, name]) => (
                  <SelectItem key={code} value={code}>{name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* API Configuration */}
          <div>
            <h4 className="text-lg font-medium mb-4">{t("api_configuration")}</h4>
            
            <div className="space-y-4">
              <div>
                <Label className="flex items-center gap-2 mb-2">
                  <Brain className="h-4 w-4 text-primary" />
                  {t("gemini_api_key")}
                </Label>
                <Input
                  type="password"
                  placeholder={t("gemini_api_key")}
                  value={formData.geminiApiKey}
                  onChange={(e) => setFormData(prev => ({ ...prev, geminiApiKey: e.target.value }))}
                />
                <a 
                  href="https://makersuite.google.com/app/apikey" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xs text-primary hover:underline mt-1 inline-block"
                >
                  {t("get_gemini_key")}
                </a>
              </div>

              <div>
                <Label className="flex items-center gap-2 mb-2">
                  <Volume2 className="h-4 w-4 text-emerald-500" />
                  {t("elevenlabs_api_key")}
                </Label>
                <Input
                  type="password"
                  placeholder={t("elevenlabs_api_key")}
                  value={formData.elevenLabsApiKey}
                  onChange={(e) => setFormData(prev => ({ ...prev, elevenLabsApiKey: e.target.value }))}
                />
                <a 
                  href="https://elevenlabs.io/app/speech-synthesis" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xs text-primary hover:underline mt-1 inline-block"
                >
                  {t("get_elevenlabs_key")}
                </a>
              </div>
            </div>

            <Card className="mt-4 bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
              <CardContent className="p-3">
                <p className="text-xs text-blue-800 dark:text-blue-200 flex items-start gap-2">
                  <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
                  {t("api_keys_secure")}
                </p>
              </CardContent>
            </Card>
          </div>

          <Separator />

          {/* Voice Settings */}
          <div>
            <h4 className="text-lg font-medium mb-4">{t("voice_settings")}</h4>
            
            <div className="space-y-4">
              <div>
                <Label className="mb-2 block">{t("voice_model")}</Label>
                <Select
                  value={formData.voiceModel}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, voiceModel: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rachel">{t("rachel_default")}</SelectItem>
                    <SelectItem value="josh">{t("josh")}</SelectItem>
                    <SelectItem value="arnold">{t("arnold")}</SelectItem>
                    <SelectItem value="adam">{t("adam")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="mb-2 block">
                  {t("speech_speed")}: {formData.speechSpeed}x
                </Label>
                <Slider
                  value={[parseFloat(formData.speechSpeed)]}
                  onValueChange={handleSpeedChange}
                  min={0.5}
                  max={2}
                  step={0.1}
                  className="w-full"
                />
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-sm">{t("auto_play_responses")}</Label>
                <Switch
                  checked={formData.autoPlayVoice}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, autoPlayVoice: checked }))}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* General Settings */}
          <div>
            <h4 className="text-lg font-medium mb-4">{t("general")}</h4>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label className="text-sm">{t("voice_responses")}</Label>
                <Switch
                  checked={formData.voiceEnabled}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, voiceEnabled: checked }))}
                />
              </div>

              <div>
                <Label className="mb-2 block">{t("max_response_length")}</Label>
                <Select
                  value={formData.maxResponseLength}
                  onValueChange={(value: "short" | "medium" | "long") => 
                    setFormData(prev => ({ ...prev, maxResponseLength: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="short">{t("short_tokens")}</SelectItem>
                    <SelectItem value="medium">{t("medium_tokens")}</SelectItem>
                    <SelectItem value="long">{t("long_tokens")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </div>

        <div className="flex gap-3 pt-4">
          <Button 
            onClick={handleSave} 
            disabled={isLoading}
            className="flex-1"
          >
            <Save className="h-4 w-4 mr-2" />
            {t("save_changes")}
          </Button>
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            disabled={isLoading}
          >
            {t("cancel")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
